﻿using Verse;

namespace DefensiveMoats
{
    public class Building_Moat : Building
    {
        
    }
}
