# rw-defensive-moats
Defensive Moats mod for RimWorld 1.0

Will be updated on 1.1 release
